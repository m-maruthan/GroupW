<?php
   include('header.php');
?>



		
		<section id="post-21" class="clearfix post-21 page type-page status-publish hentry">

			<section itemprop="articleBody">
				<div class="wpb_row pix-row vc_row-fluid vc_custom_1423309851518 light normal"><div class="bg-pos-rel">

					<div class="pix-con clearfix">
		

		<div class="pix-container">
            <div class="row">
            	<div class="col-sm-12">
				 <div class="col-sm-9">
				 	
				 	<div class="row">
				 		<div class="wpb_wrapper">
			<div class="wpb_row vc_row-fluid row recent-post">
				<div class="vc_col-sm-4">

                                <div class="event">
                                	<div class="eventsimg">
                                		<img src="image/liveevent8.jpg" alt="" style="height: 250px;">
                                	</div>
                               <div class="event-content">
                            <!-- <h3 class="title"><a href="#">Distinctively Integrate Reliable Markets</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Proactively morph enterprise communities vis-a-vis impactful human capital. Energistically orchestrate team building models for pandemic schemas. Uniquely...</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a> -->
                        </div>
                    </div>
                  </div>
                            <div class="vc_col-sm-4">
                                <div class="event"><div class="eventsimg"><img src="image/liveevent6.jpg" alt="" style="height: 250px;"></div><div class="event-content">
                            <!-- <h3 class="title"><a href="#">Uniquely Formulate Premium Synergy</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Continually customize competitive experiences and granular best practices. Interactively maintain flexible services after client-centered mindshare....</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a> -->
                        </div></div>
                            </div><div class="vc_col-sm-4">
                                <div class="event"><div class="eventsimg"><img src="image/liveevent5.jpg" alt="" style="height: 250px;"></div><div class="event-content">
                            <!-- <h3 class="title"><a href="#">Rapidiously Cultivate Cross Function</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Monotonectally foster collaborative e-markets via client-based outsourcing. Proactively orchestrate cutting-edge e-services through robust interfaces....</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a> -->
                        </div></div>
                            </div></div>
		</div>
				 	</div>
				 	<div class="row">
				 		<div class="wpb_wrapper">
			<div class="wpb_row vc_row-fluid row recent-post"><div class="vc_col-sm-4">
                                <div class="event"><div class="eventsimg"><img src="image/liveevent8.jpg" alt="" style="height: 250px;"></div><div class="event-content">
                            <!-- <h3 class="title"><a href="#">Distinctively Integrate Reliable Markets</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Proactively morph enterprise communities vis-a-vis impactful human capital. Energistically orchestrate team building models for pandemic schemas. Uniquely...</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a> -->
                        </div></div>
                            </div><div class="vc_col-sm-4">
                                <div class="event"><div class="eventsimg"><img src="image/liveevent6.jpg" alt="" style="height: 250px;"></div><div class="event-content">
                            <!-- <h3 class="title"><a href="#">Uniquely Formulate Premium Synergy</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Continually customize competitive experiences and granular best practices. Interactively maintain flexible services after client-centered mindshare....</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a> -->
                        </div></div>
                            </div><div class="vc_col-sm-4">
                                <div class="event"><div class="eventsimg"><img src="image/liveevent5.jpg" alt="" style="height: 250px;"></div><div class="event-content">
                            <!-- <h3 class="title"><a href="#">Rapidiously Cultivate Cross Function</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Monotonectally foster collaborative e-markets via client-based outsourcing. Proactively orchestrate cutting-edge e-services through robust interfaces....</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a> -->
                        </div></div>
                            </div></div>
		</div>
				 	</div>
				 </div>


				  <?php
         if(!@$id)
{
   ?>
				 
				 <div class="col-sm-3">
				 	<div class="form-body" style="min-height: 400px;">
    <ul class="nav nav-tabs final-login">
        <li class="active"><a data-toggle="tab" href="#sectionA" style="    padding: 10px;">Sign In</a></li>
        <li><a data-toggle="tab" href="#sectionB" style="    padding: 10px;">Register</a></li>
    </ul>
    <div class="tab-content">
        <div id="sectionA" class="tab-pane fade in active">
        <div class="innter-form">
            <form class="sa-innate-form" method="post" action="logincheck.php">
            <label>Email Address</label>
            <input type="email" name="email" required="required">
            <label>Password</label>
            <input type="password" name="password" required="required">
            <button type="submit" name="submit" value="submit"  >Sign In</button>
            <a href="#">Forgot Password?</a>
            </form>
            </div>
            <!-- <div class="social-login">
            <p>- - - - - - - - - - - - - Sign In With - - - - - - - - - - - - - </p>
    		<ul>
            <li><a href=""><i class="fa fa-facebook"></i> Facebook</a></li>
            <li><a href=""><i class="fa fa-google-plus"></i> Google+</a></li>
            <li><a href=""><i class="fa fa-twitter"></i> Twitter</a></li>
            </ul>
            </div> -->
            <div class="clearfix"></div>
        </div>
        <div id="sectionB" class="tab-pane fade">
			<div class="innter-form">
            <form class="sa-innate-form" method="post" action="register_action.php">
            <label>First Name:</label>
            <input type="text" name="fname" required="required">
            <label>Last Name:</label>
            <input type="text" name="lname" required="required">
            <label>Email Address:</label>
            <input type="email" name="email" required="required">
            <label>Password:</label>

            <input type="password" name="password" required="required">
             <label>Date of Birth:</label><br>
            <input type="date" name="dob" style=" width: 220px;" required="required"><br>
            <label>Contact No:</label>
            <span>
            	<br>
            <select style="width: 70px;" name="std" required="required">
            	
            	<option value="+44">+44</option>
            	<option value="1">+44</option>
            	<option value="2">+44</option>
            	<option value="3">+44</option>
            	<option value="4">+44</option>
            </select>
            <input type="text" name="mobile" style="width: 148px;" required="required"></span><br>
            <p><input type="checkbox"  required="required">Please tick box if you agree to the terms and conditions.</p>
            <button type="submit" name="submit" value="submit">Join now</button>
            
            </form>
            </div>
            <!-- <div class="social-login">
            <p>- - - - - - - - - - - - - Register With - - - - - - - - - - - - - </p>
			<ul>
            <li><a href=""><i class="fa fa-facebook"></i> Facebook</a></li>
            <li><a href=""><i class="fa fa-google-plus"></i> Google+</a></li>
            <li><a href=""><i class="fa fa-twitter"></i> Twitter</a></li>
            </ul>
            </div> -->
        </div>
    </div>
    </div>
				 </div>
      <?php
}


else{

	?>
       <div class="vc_col-sm-3">
                                <div class="event"><div class="eventsimg"><img src="image/liveevent8.jpg" alt="" style="height: 250px;"></div>
                                <div class="event-content" style="background-color: White ;">
                            <!-- <h3 class="title"><a href="#">Distinctively Integrate Reliable Markets</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Proactively morph enterprise communities vis-a-vis impactful human capital. Energistically orchestrate team building models for pandemic schemas. Uniquely...</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a> -->
                        </div></div>
                        <br><br>
                         <div class="event"><div class="eventsimg"><img src="image/liveevent8.jpg" alt="" style="height: 250px;"></div>
                                <div class="event-content" style="background-color: White ;">
                            <!-- <h3 class="title"><a href="#">Distinctively Integrate Reliable Markets</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Proactively morph enterprise communities vis-a-vis impactful human capital. Energistically orchestrate team building models for pandemic schemas. Uniquely...</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a> -->
                        </div></div>
                            </div>

	<?php
}
?>






			</div>
            </div>
			
			
	

	</div>
</div>
</div>
</div>
<div class="wpb_row pix-row vc_row-fluid vc_custom_1417500238804 dark normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-12 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<section class="eventform newsection">

			
			<div class="event-title">
				<small>Find what you want</small>
				<h2 class="title">event </h2>
			</div>

		<div class="eventform-con">
			<form method="post" action="searchevent.php">

			<input name="post_type" type="hidden" value="pix_event">
				<div class="form-input search-location">
					<input name="keyword" type="text" value="" placeholder="Search Keyword">
					<i class="icon fa fa-search"></i>
				</div>

				<div class="form-input">
					<input name="date" placeholder="mm/dd/yy" class="date_timepicker_start">
					<i class="open icon fa fa-calendar"></i>
				</div>

				<div class="form-input">
					
						<input type="text" name="loc" style="margin-top: 0px;" />
						<i class="open icon fa fa-map-marker"></i>
					</div>

					
					<button name="event_search" value="1" type="submit" class="btn btn-md btn-pri">fınd event</button>
					
				</form>
			</div>
	
	
</section>
		</div> 
	</div> 

	</div></div></div></div>
	<div class="wpb_row pix-row vc_row-fluid dark normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-12 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="tabs event-tab upcoming-popular-tab">
				<ul class="clearfix">
					<li>
						<a href="#tabs180215469">Popular Events</a>
						
					</li>
					<li>
						<a href="#tabs1062277384">Upcoming Events</a>
					</li>
				</ul>
				<div id="tabs1062277384">
	                <div class="event-container">
	                    <div class="row"><div>No Events Found.</div></div>
	                </div>
	            </div><div id="tabs180215469">
	                <div class="event-container">
	                    <div class="row">
                           <?php
		                       $result= mysqli_query($conn,"$sqlevent");
		                       // $rows= mysqli_fetch_array($result);

                                  While($row=mysqli_fetch_assoc($result))
                                    {

				 	       ?>
	                    	<div class="col-md-3">
                        		<div class="event bg">
                            		<div class='eventsimg'>
                            			<img src='images/<?php echo $row['event_image'];?>' alt='' style="height: 200px;">
                            		</div>
                            		<div class="event-content">
                                	<h3 class="title"><?php echo $row['event_title'];?>
                                		<p>
                                		<?php echo $row['event_description'];?>
                                	</p>

                                    <?php
                                    
                                   if(!$id)
                                   {

                                   }else{
                                    ?>
                                	<a href="eventdetail.php?id=<?php echo $row['event_id']; ?>" class="btn btn-solid btn-blue btn-md">Buy Ticket</a>

                                 <?php
                                      }
                                 ?>


                                </div>
                                <div class="links three clearfix">
					                   <!--  <ul>
					                    	<li><a class="st_sharethis_large" displayText="ShareThis"><i class="icon fa fa-share"></i> share</a></li>
					                    	<li><a href="#void" class="portfolio-icon pix-like-me " data-id="122"><i class="icon fa fa-heart"></i><span class="like-count">83</span></a></li>
					                    	<li><i class="icon fa fa-comment"></i>0</li> 
					                    </ul> --> 
					               	 </div></div></div>

					               	 <?php

                                      }
					               	 ?>

					               	 

					               	</div>
	                </div>
	            </div><a href="searchevent.php" target="_self" class="clear btn btn-border btn-md btn-color">View All Event</a></div>
		</div> 
	</div> 

	</div></div></div></div><div class="wpb_row pix-row vc_row-fluid vc_custom_1423313491995 light normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-12 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class=" callout border-cover  show_dual_btn"><h2 class="title"><span>so What are You Waiting For</span></h2> <div class="background-content clearfix"><p> Appropriately benchmark exceptional catalysts for change through viral applications. Collaboratively exploit enabled catalysts for. </p> <div class="both-btn clearfix">
	            <div class="find-events">
	                <a href="searchevent.php">Find Events</a>
	            </div>

	            <div class="but-ticket">
	                <a href="bookticket.php">Buy Tickets</a>
	            </div>

	            <span class="round">or</span>
	        </div></div></div>
		</div> 
	</div> 

	</div></div></div></div>

	<div class="wpb_row pix-row vc_row-fluid light normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-12 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			
		</div> 
	</div> 

	</div></div></div></div>


	<div class="wpb_row pix-row vc_row-fluid vc_custom_1423315608614 dark normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-3 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="event icon-box bg add_bg_hover"><div class="eventsicon square-border color md">
						<i class="fa fa-heart-o"></i>
					</div><div class="event-content">
						<h2 class="title">7/24 Everytime Event</h2><p>Professionally e-enable exceptional partnerships and cross-media data.[...] </p></div>
			</div>
		</div> 
	</div> 

	<div class="vc_col-sm-3 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="event icon-box bg add_bg_hover"><div class="eventsicon square-border color md">
						<i class="fa fa-calendar-o"></i>
					</div><div class="event-content">
						<h2 class="title">25+ Events Location</h2><p>Holisticly transition intuitive markets through dynamic leadership skills.[...] </p></div>
			</div>
		</div> 
	</div> 

	<div class="vc_col-sm-3 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="event icon-box bg add_bg_hover"><div class="eventsicon square-border color md">
						<i class="fa fa-umbrella"></i>
					</div><div class="event-content">
						<h2 class="title">50+ speakers</h2><p>Credibly expedite strategic products without granular interfaces.[...] </p></div>
			</div>
		</div> 
	</div> 

	<div class="vc_col-sm-3 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="event icon-box bg add_bg_hover"><div class="eventsicon square-border color md">
						<i class="fa fa-star-o"></i>
					</div><div class="event-content">
						<h2 class="title">Party After Events</h2><p>Synergistically iterate empowered testing procedures for systems.[...] </p></div>
			</div>
		</div> 
	</div> 

	</div></div></div></div>


			</section>

		</section>

				
		<?php
          include('footer.php');
		?>