<!doctype html>

 <html lang="en" class="no-js">

	<head>
		<meta charset="utf-8">

				<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

		<title>Comedyrunners</title>

				<meta name="HandheldFriendly" content="True">
		<meta name="MobileOptimized" content="320">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

				<script src="../cdn-cgi/apps/head/gsu8BXqj8q1wXqkFE48zeCm3_-M.js"></script>
		<link rel="icon" href="http://innwithemes.com/eventonwp/wp-content/themes/event/favicon.png">

				<title>Comedyrunners</title>
<link rel="alternate" type="application/rss+xml" title="EventOn &raquo; Feed" href="http://innwithemes.com/eventonwp/feed/" />
<link rel="alternate" type="application/rss+xml" title="EventOn &raquo; Comments Feed" href="http://innwithemes.com/eventonwp/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="EventOn &raquo; Home3 Comments Feed" href="http://innwithemes.com/eventonwp/home3/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/innwithemes.com\/eventonwp\/wp-includes\/js\/wp-emoji-release.min.js"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='wp-content/plugins/contact-form-7/includes/css/styles.css' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='wp-content/plugins/revslider/public/assets/css/settings.css' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
.tp-caption a{color:#fff;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}
</style>
<link rel='stylesheet' id='wpclef-main-css'  href='wp-content/plugins/wpclef/assets/dist/css/main.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='eventon-theme-fonts-css'  href='http://fonts.googleapis.com/css?family=Source+Sans+Pro%3A100%2C100italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C700%2C700italic%2C900%2C900italic%2C&#038;subset=latin' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='wp-content/plugins/js_composer/assets/css/js_composer.css' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css-css'  href='wp-content/themes/event/library/css/font-awesome.css' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css-css'  href='wp-content/themes/event/library/css/bootstrap.min.css' type='text/css' media='all' />


<link rel='stylesheet' id='plugins-css-css'  href='wp-content/themes/event/library/css/plugins.css' type='text/css' media='all' />
<link rel='stylesheet' id='woo-css-css'  href='wp-content/themes/event/library/css/woo.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css-css'  href='wp-content/themes/event/library/css/main.css' type='text/css' media='all' />
<link rel='stylesheet' id='color-stylesheet-css'  href='wp-content/themes/event/library/css/color-css/default.css' type='text/css' media='all' />
<link rel='stylesheet' id='custom-css-css'  href='wp-content/themes/event/library/css/custom_styles.css' type='text/css' media='all' />


<link rel='stylesheet' id='googleFonts-css'  href='http://fonts.googleapis.com/css?family=Lato%3A400%2C700%2C400italic%2C700italic' type='text/css' media='all' />


<script type='text/javascript' src='wp-includes/js/jquery/jquery.js'></script>


<script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js'></script>
<script type='text/javascript' src='wp-content/themes/event/library/js/libs/modernizr.custom.min.js'></script>
<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 5.2.5 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1423309851518{padding-top: 70px !important;padding-bottom: 70px !important;background-image: url(image/banner.png) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}
.vc_custom_1417500238804{padding-top: 0px !important;padding-bottom: 0px !important;background-color: #735cb0 !important;}.vc_custom_1423313491995{background-image: url(http://innwithemes.com/eventonwp/wp-content/uploads/2014/12/background-bg.png?id=26) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1423315608614{padding-top: 80px !important;padding-bottom: 80px !important;background-image: url(http://innwithemes.com/eventonwp/wp-content/uploads/2014/12/background-bg.png?id=26) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}</style>		
	

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
     #tip 
        {
            display:none;  
        }

        .fadeIn
        {
          animation-duration: 3s;
        }

        .form-control
        {
          border-radius:0px;
          border:1px solid #EDEDED;
        }

        .form-control:focus
        {
          border:1px solid #00bfff;
        }

        .textarea-contact
        {
          resize:none; 
        }

        .btn-send
        {
          border-radius: 0px;
          border:1px solid #00bfff;
          background:#00bfff;
          color:#fff; 
        }

        .btn-send:hover
        {
          border:1px solid #00bfff;
          background:#fff;
          color:#00bfff;
          transition:background 0.5s;   
        }

        .second-portion
        {
          margin-top:50px; 
        }

            @import "//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css";
    @import "http://fonts.googleapis.com/css?family=Roboto:400,500";

    .box > .icon { text-align: center; position: relative; }
    .box > .icon > .image { position: relative; z-index: 2; margin: auto; width: 105px; height: 88px; border: 8px solid white; line-height: 88px; border-radius: 50%; background: #00bfff; vertical-align: middle; }
    .box > .icon:hover > .image { background: #333; }
    .box > .icon > .image > i { font-size: 36px !important; color: #fff !important; }
    .box > .icon:hover > .image > i { color: white !important; }
    .box > .icon > .info { margin-top: -24px; background: rgba(0, 0, 0, 0.04); border: 1px solid #e0e0e0; padding: 15px 0 10px 0; min-height:190px;}
    .box > .icon:hover > .info { background: rgba(0, 0, 0, 0.04); border-color: #e0e0e0; color: #00bfff; }
    .box > .icon > .info > h3.title { font-family: "Robot",sans-serif !important; font-size: 16px; color: #222; font-weight: 700; }
    .box > .icon > .info > p { font-family: "Robot",sans-serif !important; font-size: 13px; color: #666; line-height: 1.5em; margin: 20px;}
    .box > .icon:hover > .info > h3.title, .box > .icon:hover > .info > p, .box > .icon:hover > .info > .more > a { color: #222; }
    .box > .icon > .info > .more a { font-family: "Robot",sans-serif !important; font-size: 12px; color: #222; line-height: 12px; text-transform: uppercase; text-decoration: none; }
    .box > .icon:hover > .info > .more > a { color: #fff; padding: 6px 8px; background-color: #63B76C; }
    .box .space { height: 30px; }

    @media only screen and (max-width: 768px)
    {
      .contact-form
      {
        margin-top:25px; 
      }

      .btn-send
      {
        width: 100%;
        padding:10px; 
      }

      .second-portion
      {
        margin-top:25px; 
      }
    }
  /* Conatct end */
   </style>
<style>
	/* form */

.form-body{
    background:#fff;
    padding:20px;
}
.login-form{
    background:rgba(255,255,255,0.8);
	padding:20px;
	border-top:3px solid#3e4043;
}
.innter-form{
	padding-top:20px;
}
.final-login li{
	width:50%;
}

.nav-tabs {
    border-bottom: none !important;
}

.nav-tabs>li{
	color:#222 !important;
}
.nav-tabs>li.active>a, .nav-tabs>li.active>a:hover, .nav-tabs>li.active>a:focus {
    color: #fff;
    background-color: #d14d42;
    border: none !important;
    border-bottom-color: transparent;
	border-radius:none !important;
}
.nav-tabs>li>a {
    margin-right: 2px;
    line-height: 1.428571429;
    border: none !important;
    border-radius:none !important;
	text-transform:uppercase;
	font-size:16px;
}

.social-login{
	text-align:center;
	font-size:12px;
}
.social-login p{
	margin:15px 0;
}
.social-login ul{
	margin:0;
	padding:0;
	list-style-type:none;
}
.social-login ul li{
	width:33%;
	float:left;
    clear:fix;
}
.social-login ul li a{
	font-size:13px;
	color:#fff;
	text-decoration:none;
	padding:10px 0;
	display:block;
}
.social-login ul li:nth-child(1) a{
	background:#3b5998;
}
.social-login ul li:nth-child(2) a{
	background:#e74c3d;
}
.social-login ul li:nth-child(3) a{
	background:#3698d9;
}
.sa-innate-form input[type=text], input[type=password], input[type=file], textarea, select, email{
    font-size:13px;
	padding:10px;
	border:1px solid#ccc;
	outline:none;
	width:100%;
	margin:8px 0;
	
}
.sa-innate-form input[type=submit]{
    border:1px solid#e64b3b;
	background:#e64b3b;
	color:#fff;
	padding:10px 25px;
	font-size:14px;
	margin-top:5px;
	}
	.sa-innate-form input[type=submit]:hover{
	border:1px solid#db3b2b;
	background:#db3b2b;
	color:#fff;
	}
	
	.sa-innate-form button{
	border:1px solid#e64b3b;
	background:#e64b3b;
	color:#fff;
	padding:10px 25px;
	font-size:14px;
	margin-top:5px;
	}
	.sa-innate-form button:hover{
	border:1px solid#db3b2b;
	background:#db3b2b;
	color:#fff;
	}
    .sa-innate-form p{
        font-size:13px;
        padding-top:10px;
    }
</style>

<style>
.switch {
  position: relative;
  display: inline-block;
  width: 50px;
  height: 24px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 24px;
}

.slider.round:before {
  border-radius: 30%;
}
</style>
<script> 
$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
});
</script>

<style> 
#panel, #flip {
    padding: 5px;
  
   
}
#panel {
    padding: 50px;
    display: none;
}


</style>


<style>
	.uploader {
  display: block;
  clear: both;
  margin: 0 auto;
  width: 100%;
  max-width: 600px;
}
.uploader label {
  float: left;
  clear: both;
  width: 100%;
  padding: 2rem 1.5rem;
  text-align: center;
  background: #fff;
  border-radius: 7px;
  border: 3px solid #eee;
  -webkit-transition: all .2s ease;
  transition: all .2s ease;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
}
.uploader label:hover {
  border-color: #454cad;
}
.uploader label.hover {
  border: 3px solid #454cad;
  box-shadow: inset 0 0 0 6px #eee;
}
.uploader label.hover #start i.fa {
  -webkit-transform: scale(0.8);
          transform: scale(0.8);
  opacity: 0.3;
}
.uploader #start {
  float: left;
  clear: both;
  width: 100%;
}
.uploader #start.hidden {
  display: none;
}
.uploader #start i.fa {
  font-size: 50px;
  margin-bottom: 1rem;
  -webkit-transition: all .2s ease-in-out;
  transition: all .2s ease-in-out;
}
.uploader #response {
  float: left;
  clear: both;
  width: 100%;
}
.uploader #response.hidden {
  display: none;
}
.uploader #response #messages {
  margin-bottom: .5rem;
}
.uploader #file-image {
  display: inline;
  margin: 0 auto .5rem auto;
  width: auto;
  height: auto;
  max-width: 180px;
}
.uploader #file-image.hidden {
  display: none;
}
.uploader #notimage {
  display: block;
  float: left;
  clear: both;
  width: 100%;
}
.uploader #notimage.hidden {
  display: none;
}
.uploader progress,
.uploader .progress {
  display: inline;
  clear: both;
  margin: 0 auto;
  width: 100%;
  max-width: 180px;
  height: 8px;
  border: 0;
  border-radius: 4px;
  background-color: #eee;
  overflow: hidden;
}
.uploader .progress[value]::-webkit-progress-bar {
  border-radius: 4px;
  background-color: #eee;
}
.uploader .progress[value]::-webkit-progress-value {
  background: -webkit-linear-gradient(left, #393f90 0%, #454cad 50%);
  background: linear-gradient(to right, #393f90 0%, #454cad 50%);
  border-radius: 4px;
}
.uploader .progress[value]::-moz-progress-bar {
  background: linear-gradient(to right, #393f90 0%, #454cad 50%);
  border-radius: 4px;
}
.uploader input[type="file"] {
  display: none;
}
.uploader div {
  margin: 0 0 .5rem 0;
  color: #5f6982;
}
.uploader .btn {
  display: inline-block;
  margin: .5rem .5rem 1rem .5rem;
  clear: both;
  font-family: inherit;
  font-weight: 700;
  font-size: 14px;
  text-decoration: none;
  text-transform: initial;
  border: none;
  border-radius: .2rem;
  outline: none;
  padding: 0 1rem;
  height: 36px;
  line-height: 36px;
  color: #fff;
  -webkit-transition: all 0.2s ease-in-out;
  transition: all 0.2s ease-in-out;
  box-sizing: border-box;
  background: #454cad;
  border-color: #454cad;
  cursor: pointer;
}

</style>
<script>
	
	// File Upload
// 
function ekUpload(){
  function Init() {

    console.log("Upload Initialised");

    var fileSelect    = document.getElementById('file-upload'),
        fileDrag      = document.getElementById('file-drag'),
        submitButton  = document.getElementById('submit-button');

    fileSelect.addEventListener('change', fileSelectHandler, false);

    // Is XHR2 available?
    var xhr = new XMLHttpRequest();
    if (xhr.upload) {
      // File Drop
      fileDrag.addEventListener('dragover', fileDragHover, false);
      fileDrag.addEventListener('dragleave', fileDragHover, false);
      fileDrag.addEventListener('drop', fileSelectHandler, false);
    }
  }

  function fileDragHover(e) {
    var fileDrag = document.getElementById('file-drag');

    e.stopPropagation();
    e.preventDefault();

    fileDrag.className = (e.type === 'dragover' ? 'hover' : 'modal-body file-upload');
  }

  function fileSelectHandler(e) {
    // Fetch FileList object
    var files = e.target.files || e.dataTransfer.files;

    // Cancel event and hover styling
    fileDragHover(e);

    // Process all File objects
    for (var i = 0, f; f = files[i]; i++) {
      parseFile(f);
      uploadFile(f);
    }
  }

  // Output
  function output(msg) {
    // Response
    var m = document.getElementById('messages');
    m.innerHTML = msg;
  }

  function parseFile(file) {

    console.log(file.name);
    output(
      '<strong>' + encodeURI(file.name) + '</strong>'
    );
    
    // var fileType = file.type;
    // console.log(fileType);
    var imageName = file.name;

    var isGood = (/\.(?=gif|jpg|png|jpeg)/gi).test(imageName);
    if (isGood) {
      document.getElementById('start').classList.add("hidden");
      document.getElementById('response').classList.remove("hidden");
      document.getElementById('notimage').classList.add("hidden");
      // Thumbnail Preview
      document.getElementById('file-image').classList.remove("hidden");
      document.getElementById('file-image').src = URL.createObjectURL(file);
    }
    else {
      document.getElementById('file-image').classList.add("hidden");
      document.getElementById('notimage').classList.remove("hidden");
      document.getElementById('start').classList.remove("hidden");
      document.getElementById('response').classList.add("hidden");
      document.getElementById("file-upload-form").reset();
    }
  }

  function setProgressMaxValue(e) {
    var pBar = document.getElementById('file-progress');

    if (e.lengthComputable) {
      pBar.max = e.total;
    }
  }

  function updateFileProgress(e) {
    var pBar = document.getElementById('file-progress');

    if (e.lengthComputable) {
      pBar.value = e.loaded;
    }
  }

  function uploadFile(file) {

    var xhr = new XMLHttpRequest(),
      fileInput = document.getElementById('class-roster-file'),
      pBar = document.getElementById('file-progress'),
      fileSizeLimit = 1024; // In MB
    if (xhr.upload) {
      // Check if file is less than x MB
      if (file.size <= fileSizeLimit * 1024 * 1024) {
        // Progress bar
        pBar.style.display = 'inline';
        xhr.upload.addEventListener('loadstart', setProgressMaxValue, false);
        xhr.upload.addEventListener('progress', updateFileProgress, false);

        // File received / failed
        xhr.onreadystatechange = function(e) {
          if (xhr.readyState == 4) {
            // Everything is good!

            // progress.className = (xhr.status == 200 ? "success" : "failure");
            // document.location.reload(true);
          }
        };

        // Start upload
        xhr.open('POST', document.getElementById('file-upload-form').action, true);
        xhr.setRequestHeader('X-File-Name', file.name);
        xhr.setRequestHeader('X-File-Size', file.size);
        xhr.setRequestHeader('Content-Type', 'multipart/form-data');
        xhr.send(file);
      } else {
        output('Please upload a smaller file (< ' + fileSizeLimit + ' MB).');
      }
    }
  }

  // Check for the various File API support.
  if (window.File && window.FileList && window.FileReader) {
    Init();
  } else {
    document.getElementById('file-drag').style.display = 'none';
  }
}
ekUpload();
</script>
	</head>

	<body class="home page page-id-21 page-template-default wpb-js-composer js-comp-ver-4.4.2 vc_responsive">

    
         <header class="header-container">

            <div class="header-top">
                        <div class="container">
                            <div class="row"><div class="col-md-6"><ul class="contact-details clearfix">
                                            <li><i class="icon fa fa-paper-plane-o"></i><a href="#"><span class="__cf_email__" data-cfemail="f891969e97b881978d8a8b918c9dd69b9795">[email&#160;:Comedyrunners@gmail.com]</span></a></li>
                                            <li><i class="icon fa fa-phone"></i> 07737978513</li>
                                        </ul></div><div class="col-md-6"><div class="cart-social"><div class="social-icon"><a href="#" class="facebook fa fa-facebook"></a><a href="#" class="twitter fa fa-twitter"></a><a href="#" class="googleplus fa fa-google-plus"></a><a href="#" class="linkedin fa fa-linkedin"></a><a href="#" class="flickr fa fa-flickr"></a><a href="#" class="pinterest fa fa-pinterest"></a><a href="#" class="tumblr fa fa-tumblr"></a><a href="#" class="rss fa fa-rss"></a></div>

   

</div></div></div> 
                       </div>     
                    </div>        
           <div class="main-header affix clearfix">
                <div class="container">
                     <div class="inner-header">
                        
                        	<!-- <a href="index.php" id="logo"> -->
                        		<a href="index.php">
                        		<img src="logo.jpg" style="width: 200px; height: 90px;">
                        	</a>
                       
                                                    <div id="sb-search" class="sb-search">
                                <form role="search" method="get" action="#">
                                    <input class="sb-search-input" placeholder="Search For Event..." type="text" value="" name="s" id="s">
                                    <input class="sb-search-submit" type="submit" id="searchsubmit" value="">
                                    <span class="sb-icon-search"></span>
                                </form>
                            </div>
                                                 
                            <div class="mobile-menu-icon">
                                <i class="fa fa-bars"></i>
                            </div> 
                     
                          <nav  class="main-nav mobile-menu" role="navigation">
                             <ul id="menu-main-menu" class="nav top-nav cf">
                             	

<li id="menu-item-185" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-185 pix-submenu external"><a href="index.php">HOME</a></li>
<li id="menu-item-185" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-185 pix-submenu external"><a href="#">FEEDBACK</a></li>
<li id="menu-item-46" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-46 pix-submenu external"><a href="#">ABOUT US</a></li>
<li id="menu-item-55" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-55 pix-submenu external"><a href="contact.php">CONTACT US</a></li>
<li id="menu-item-212" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-212 pix-submenu external"><a href="faq.php">FAQ</a></li>
<li id="menu-item-119" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119 pix-submenu external"><a href="#">CREATE EVENT</a></li>
<li id="menu-item-145" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-145 pix-submenu external">
                             	<a href="userevent.php">Username</a>
<ul style="display: none;" class="sub-menu">
	<li id="menu-item-273" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-273 external"><a href="myaccount.php">My Account</a></li>
	
</ul>
</li>



</ul>                         </nav>
                         <!-- NAV -->
                    </div>
                </div> 
          </div>
     </header>
      <!-- HEADER --> 


<div class="wpb_row pix-row vc_row-fluid light normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
    <div class="pix-container">
  <div class="vc_col-sm-12 wpb_column vc_column_container ">
    <div class="wpb_wrapper">
          <div class="jumbotron">
            <h1>"Creating Memories Lasting A Lifetime..."</h1>
          </div>

          <div class="row">
            <div class="col-sm-12" style="background-color: white;">
                      <p style="font-size: 18px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla convallis egestas rhoncus. Donec facilisis fermentum sem, ac viverra ante luctus vel. Donec vel mauris quam.</p>
                        <p style="font-size: 18px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla convallis egestas rhoncus. Donec facilisis fermentum sem, ac viverra ante luctus vel. Donec vel mauris quam. Lorem ipsum dolor sit amet. Nulla convallis egestas rhoncus.</p>
                    </div>


                      <div class="container second-portion">
  <div class="row">
        <!-- Boxes de Acoes -->
      <div class="col-xs-12 col-sm-6 col-lg-4">
      <div class="box">             
        <div class="icon">
          <div class="image"><i class="fa fa-check" aria-hidden="true"></i></div>
          <div class="info">
           <!--  <h3 class="title">MAIL & WEBSITE</h3> -->
            <p>
             <!--  <i class="fa fa-envelope" aria-hidden="true"></i> &nbsp gondhiyahardik6610@gmail.com -->
              <br>
              <h3>Accredited by trading
standards.</h3>
              <br>
              <!-- <i class="fa fa-globe" aria-hidden="true"></i> &nbsp www.hardikgondhiya.com -->
            </p>
          
          </div>
        </div>
        <div class="space"></div>
      </div> 
    </div>
      
        <div class="col-xs-12 col-sm-6 col-lg-4">
      <div class="box">             
        <div class="icon">
          <div class="image"><i class="material-icons">looks_one <sup style="top: -1.5em!important;font-size: 40%!important; font-weight: bold;">ST</sup></i></div>
          <div class="info">
           <!--  <h3 class="title">CONTACT</h3> -->
              <p>
             <!--  <i class="fa fa-mobile" aria-hidden="true"></i> &nbsp (+91)-9624XXXXX -->
              <br>
              <h3>Number one event
platform globally</h3>
              <br>
              <!-- <i class="fa fa-mobile" aria-hidden="true"></i> &nbsp  (+91)-7567065254 --> 
            </p>
          </div>
        </div>
        <div class="space"></div>
      </div> 
    </div>
      
        <div class="col-xs-12 col-sm-6 col-lg-4">
      <div class="box">             
        <div class="icon">
          <div class="image"><i class="fa fa-ticket" aria-hidden="true"></i></div>
          <div class="info">
           <!--  <h3 class="title">ADDRESS</h3> -->
              <p>
               <!-- <i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp 15/3 Junction Plot 
               "Shree Krishna Krupa", Rajkot - 360001. -->
               <br>
               <h3>Millions of tickets sold/
processed each week.</h3>
            </p>
          </div>
        </div>
        <div class="space"></div>
      </div> 
    </div>        
    <!-- /Boxes de Acoes -->
    
    <!--My Portfolio  dont Copy this -->
      
  </div>
</div>
          </div>
    </div>  
  </div> 

  </div></div></div></div>
	

			
		<footer class="footer col3" role="contentinfo">

							

					<div class="main-footer"><div id="inner-footer" class="container"><div id="text-2" class="widget widget_text clearfix "><h2 class="title">About Us<span class="border"></span></h2>			<div class="textwidget">Dynamically administrate equity invested networks via competitive human capital. Quickly orchestrate back end services whereas user manufactured products. Collaboratively fashion emerging metrics through real-time customer service. Progressively iterate dynamic interfaces after mission critical. Distinctively underwhelm plug-and-play meta-services and leading-edge paradigms.</div>
		</div>		
		<div id="pix_recent_post-3" class="widget recentpost clearfix ">		<h2 class="title">Recent Posts<span class="border"></span></h2>		
			<div class="sidebar-post-widget">
			<ul>
											<li class="clearfix">									
									<div class="content ">
										<p><a href="#">Professionally build market positioning materials</a></p>
										<span class="meta">March 9, 2015</span>
																			</div>
								</li>
	        
											<li class="clearfix">									
									<div class="content ">
										<p><a href="#">Globally benchmark strategic e-services</a></p>
										<span class="meta">March 9, 2015</span>
																			</div>
								</li>
	        
											<li class="clearfix">									
									<div class="content ">
										<p><a href="#">Rapidiously pontificate inexpensive customer service</a></p>
										<span class="meta">March 9, 2015</span>
																			</div>
								</li>
	        
						</ul>
		</div>
		</div>		
		<div id="pix_popular_post-3" class="widget popularpost clearfix ">		
			<h2 class="title">Address<span class="border"></span></h2>		
			<div class="sidebar-post-widget">
			<ul>
							<li class="clearfix">					
					<div class="content ">
						<p><a href="#">52 blanford street 
                                     <br>  London<br>
                                    Wx1h0bx</a><br>
                        <p>Contact No.:07737978513</p>
                                </p>
						<!-- <span class="meta">December 16, 2014</span> -->
											</div>
				</li>
	        
							<!-- <li class="clearfix">					
					<div class="content ">
						<p><a href="#">Rapidiously Cultivate Cross Function</a></p>
						<span class="meta">December 16, 2014</span>
											</div>
				</li>
	        
							<li class="clearfix">					
					<div class="content ">
						<p><a href="#">Distinctively Integrate Reliable Markets</a></p>
						<span class="meta">December 16, 2014</span>
											</div>
				</li> -->
	        
						</ul>
		</div>
		</div></div></div>
				

			<div id="copyright">
						<div class="container">
							<div class="copyright row"><div class="col-md-6"><p>© 2017 <a href="#">Comedyrunners</a> , All Rights Reserved.</p></div><div class="col-md-6"><div class="social-icon pull-right"><a href="#" class="facebook fa fa-facebook"></a><a href="#" class="twitter fa fa-twitter"></a><a href="#" class="googleplus fa fa-google-plus"></a><a href="#" class="linkedin fa fa-linkedin"></a><a href="#" class="flickr fa fa-flickr"></a><a href="#" class="pinterest fa fa-pinterest"></a><a href="#" class="tumblr fa fa-tumblr"></a><a href="#" class="rss fa fa-rss"></a></div></div></div>
						</div>
					</div>
		</footer>

		

				<script data-cfasync="false" src="../cdn-cgi/scripts/ddc5a536/cloudflare-static/email-decode.min.js"></script><script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/plugins/contact-form-7/includes/js/scripts.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif","i18n_view_cart":"View Cart","cart_url":"http:\/\/innwithemes.com\/eventonwp\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
var wc_add_to_cart_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif","i18n_view_cart":"View Cart","cart_url":"http:\/\/innwithemes.com\/eventonwp\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js'></script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif"};
var woocommerce_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif"};
/* ]]> */
</script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js'></script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","fragment_name":"wc_fragments"};
var wc_cart_fragments_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pixLike = {"ajaxurl":"http:\/\/innwithemes.com\/eventonwp\/wp-admin\/admin-ajax.php","liked":"You already liked this!"};
/* ]]> */
</script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/framework/required-functions/pix-like-me/js/like-me.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-includes/js/comment-reply.min.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/library/js/scripts.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/library/js/plugins.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/library/js/main.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/plugins/js_composer/assets/js/js_composer_front.js'></script>

	</body>

</html> <!-- end of site. what a ride! -->