<!doctype html>

 <html lang="en" class="no-js">

	<head>
		<meta charset="utf-8">

				<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

		<title>Comedyrunners</title>

				<meta name="HandheldFriendly" content="True">
		<meta name="MobileOptimized" content="320">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

				<script src="../cdn-cgi/apps/head/gsu8BXqj8q1wXqkFE48zeCm3_-M.js"></script>

			
		<link rel="icon" href="http://innwithemes.com/eventonwp/wp-content/themes/event/favicon.png">
		

				<title>Comedyrunners</title>
<link rel="alternate" type="application/rss+xml" title="EventOn &raquo; Feed" href="http://innwithemes.com/eventonwp/feed/" />
<link rel="alternate" type="application/rss+xml" title="EventOn &raquo; Comments Feed" href="http://innwithemes.com/eventonwp/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="EventOn &raquo; Home3 Comments Feed" href="http://innwithemes.com/eventonwp/home3/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/innwithemes.com\/eventonwp\/wp-includes\/js\/wp-emoji-release.min.js"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='wp-content/plugins/contact-form-7/includes/css/styles.css' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='wp-content/plugins/revslider/public/assets/css/settings.css' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
.tp-caption a{color:#fff;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}
</style>
<link rel='stylesheet' id='wpclef-main-css'  href='wp-content/plugins/wpclef/assets/dist/css/main.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='eventon-theme-fonts-css'  href='http://fonts.googleapis.com/css?family=Source+Sans+Pro%3A100%2C100italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C700%2C700italic%2C900%2C900italic%2C&#038;subset=latin' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='wp-content/plugins/js_composer/assets/css/js_composer.css' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css-css'  href='wp-content/themes/event/library/css/font-awesome.css' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css-css'  href='wp-content/themes/event/library/css/bootstrap.min.css' type='text/css' media='all' />


<link rel='stylesheet' id='plugins-css-css'  href='wp-content/themes/event/library/css/plugins.css' type='text/css' media='all' />
<link rel='stylesheet' id='woo-css-css'  href='wp-content/themes/event/library/css/woo.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css-css'  href='wp-content/themes/event/library/css/main.css' type='text/css' media='all' />
<link rel='stylesheet' id='color-stylesheet-css'  href='wp-content/themes/event/library/css/color-css/default.css' type='text/css' media='all' />
<link rel='stylesheet' id='custom-css-css'  href='wp-content/themes/event/library/css/custom_styles.css' type='text/css' media='all' />


<link rel='stylesheet' id='googleFonts-css'  href='http://fonts.googleapis.com/css?family=Lato%3A400%2C700%2C400italic%2C700italic' type='text/css' media='all' />


<script type='text/javascript' src='wp-includes/js/jquery/jquery.js'></script>


<script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js'></script>
<script type='text/javascript' src='wp-content/themes/event/library/js/libs/modernizr.custom.min.js'></script>
<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 5.2.5 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1423309851518{padding-top: 70px !important;padding-bottom: 70px !important;background-image: url(image/banner.png) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}
.vc_custom_1417500238804{padding-top: 0px !important;padding-bottom: 0px !important;background-color: #735cb0 !important;}.vc_custom_1423313491995{background-image: url(http://innwithemes.com/eventonwp/wp-content/uploads/2014/12/background-bg.png?id=26) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1423315608614{padding-top: 80px !important;padding-bottom: 80px !important;background-image: url(http://innwithemes.com/eventonwp/wp-content/uploads/2014/12/background-bg.png?id=26) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}</style>		
	


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
	/* form */

.form-body{
    background:#fff;
    padding:20px;
}
.login-form{
    background:rgba(255,255,255,0.8);
	padding:20px;
	border-top:3px solid#3e4043;
}
.innter-form{
	padding-top:20px;
}
.final-login li{
	width:50%;
}

.nav-tabs {
    border-bottom: none !important;
}

.nav-tabs>li{
	color:#222 !important;
}
.nav-tabs>li.active>a, .nav-tabs>li.active>a:hover, .nav-tabs>li.active>a:focus {
    color: #fff;
    background-color: #d14d42;
    border: none !important;
    border-bottom-color: transparent;
	border-radius:none !important;
}
.nav-tabs>li>a {
    margin-right: 2px;
    line-height: 1.428571429;
    border: none !important;
    border-radius:none !important;
	text-transform:uppercase;
	font-size:16px;
}

.social-login{
	text-align:center;
	font-size:12px;
}
.social-login p{
	margin:15px 0;
}
.social-login ul{
	margin:0;
	padding:0;
	list-style-type:none;
}
.social-login ul li{
	width:33%;
	float:left;
    clear:fix;
}
.social-login ul li a{
	font-size:13px;
	color:#fff;
	text-decoration:none;
	padding:10px 0;
	display:block;
}
.social-login ul li:nth-child(1) a{
	background:#3b5998;
}
.social-login ul li:nth-child(2) a{
	background:#e74c3d;
}
.social-login ul li:nth-child(3) a{
	background:#3698d9;
}
.sa-innate-form input[type=text], input[type=password], input[type=file], textarea, select, email{
    font-size:13px;
	padding:10px;
	border:1px solid#ccc;
	outline:none;
	width:100%;
	margin:8px 0;
	
}
.sa-innate-form input[type=submit]{
    border:1px solid#e64b3b;
	background:#e64b3b;
	color:#fff;
	padding:10px 25px;
	font-size:14px;
	margin-top:5px;
	}
	.sa-innate-form input[type=submit]:hover{
	border:1px solid#db3b2b;
	background:#db3b2b;
	color:#fff;
	}
	
	.sa-innate-form button{
	border:1px solid#e64b3b;
	background:#e64b3b;
	color:#fff;
	padding:10px 25px;
	font-size:14px;
	margin-top:5px;
	}
	.sa-innate-form button:hover{
	border:1px solid#db3b2b;
	background:#db3b2b;
	color:#fff;
	}
    .sa-innate-form p{
        font-size:13px;
        padding-top:10px;
    }
</style>

	</head>

	<body class="home page page-id-21 page-template-default wpb-js-composer js-comp-ver-4.4.2 vc_responsive">

    
         <header class="header-container">

            <div class="header-top">
                        <div class="container">
                            <div class="row"><div class="col-md-6"><ul class="contact-details clearfix">
                                            <li><i class="icon fa fa-paper-plane-o"></i><a href="#"><span class="__cf_email__" data-cfemail="f891969e97b881978d8a8b918c9dd69b9795">[email&#160;:Comedyrunners@gmail.com]</span></a></li>
                                            <li><i class="icon fa fa-phone"></i> 07737978513</li>
                                        </ul></div><div class="col-md-6"><div class="cart-social"><div class="social-icon"><a href="#" class="facebook fa fa-facebook"></a><a href="#" class="twitter fa fa-twitter"></a><a href="#" class="googleplus fa fa-google-plus"></a><a href="#" class="linkedin fa fa-linkedin"></a><a href="#" class="flickr fa fa-flickr"></a><a href="#" class="pinterest fa fa-pinterest"></a><a href="#" class="tumblr fa fa-tumblr"></a><a href="#" class="rss fa fa-rss"></a></div>



</div></div></div> 
                       </div>     
                    </div>        
           <div class="main-header affix clearfix">
                <div class="container">
                     <div class="inner-header">
                        
                        	<!-- <a href="index.php" id="logo"> -->
                        		<a href="index.php">
                        		<img src="logo.jpg" style="width: 200px; height: 90px;">
                        	</a>
                       
                                 <div id="sb-search" class="sb-search">
                                <form role="search" method="get" action="http://innwithemes.com/eventonwp/">
                                    <input class="sb-search-input" placeholder="Search Event" type="text" value="" name="s" id="s">
                                    <input class="sb-search-submit" type="submit" id="searchsubmit" value="">
                                    <span class="sb-icon-search"></span>
                                </form>
                            </div>               
                                                 
                            <div class="mobile-menu-icon">
                                <i class="fa fa-bars"></i>
                            </div> 
                     
                          <nav  class="main-nav mobile-menu" role="navigation">
                             <ul id="menu-main-menu" class="nav top-nav cf">
                             	
<li id="menu-item-185" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-185 pix-submenu external"><a href="index.php">HOME</a></li>
<li id="menu-item-185" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-185 pix-submenu external"><a href="#">FEEDBACK</a></li>
<li id="menu-item-46" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-46 pix-submenu external"><a href="#">ABOUT US</a></li>
<li id="menu-item-55" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-55 pix-submenu external"><a href="contact.php">CONTACT US</a></li>
<li id="menu-item-212" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-212 pix-submenu external"><a href="#">FAQ</a></li>
<li id="menu-item-119" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119 pix-submenu external"><a href="#">CREATE EVENT</a></li>

</ul>                         </nav>
                         <!-- NAV -->
                    </div>
                </div> 
          </div>
     </header>
      <!-- HEADER -->  



		
		<section id="post-21" class="clearfix post-21 page type-page status-publish hentry">

			<section itemprop="articleBody">
				<div class="wpb_row pix-row vc_row-fluid vc_custom_1423309851518 light normal"><div class="bg-pos-rel">

					<div class="pix-con clearfix">
		

		<div class="pix-container">
            <div class="row">
            	<div class="col-sm-12">
				 <div class="col-sm-9">
				 	<div class="row">
				 		<div class="wpb_wrapper">
			<div class="wpb_row vc_row-fluid row recent-post"><div class="vc_col-sm-4">
                                <div class="event"><div class="eventsimg"><img src="image/liveevent8.jpg" alt="" style="height: 250px;"></div><div class="event-content">
                            <h3 class="title"><a href="#">Distinctively Integrate Reliable Markets</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Proactively morph enterprise communities vis-a-vis impactful human capital. Energistically orchestrate team building models for pandemic schemas. Uniquely...</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a>
                        </div></div>
                            </div><div class="vc_col-sm-4">
                                <div class="event"><div class="eventsimg"><img src="image/liveevent6.jpg" alt="" style="height: 250px;"></div><div class="event-content">
                            <h3 class="title"><a href="#">Uniquely Formulate Premium Synergy</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Continually customize competitive experiences and granular best practices. Interactively maintain flexible services after client-centered mindshare....</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a>
                        </div></div>
                            </div><div class="vc_col-sm-4">
                                <div class="event"><div class="eventsimg"><img src="image/liveevent5.jpg" alt="" style="height: 250px;"></div><div class="event-content">
                            <h3 class="title"><a href="#">Rapidiously Cultivate Cross Function</a></h3><ul class="meta"><li>by <a href="admin">Admin</a> </li><li>16 December, 2014</li></ul><span class="sep"></span><p>Monotonectally foster collaborative e-markets via client-based outsourcing. Proactively orchestrate cutting-edge e-services through robust interfaces....</p><a href="#" class="btn btn-md btn-solid btn-grey">Read More</a>
                        </div></div>
                            </div></div>
		</div>
				 	</div>
				 </div>
				 
				 <div class="col-sm-3">
				 	<div class="form-body" style="min-height: 400px;">
    <ul class="nav nav-tabs final-login">
        <li class="active"><a data-toggle="tab" href="#sectionA" style="    padding: 10px;">Sign In</a></li>
        <li><a data-toggle="tab" href="#sectionB" style="    padding: 10px;">Register</a></li>
    </ul>
    <div class="tab-content">
        <div id="sectionA" class="tab-pane fade in active">
        <div class="innter-form">
            <form class="sa-innate-form" method="post">
            <label>Email Address</label>
            <input type="text" name="username">
            <label>Password</label>
            <input type="password" name="password">
            <button type="submit">Sign In</button>
            <a href="">Forgot Password?</a>
            </form>
            </div>
            <!-- <div class="social-login">
            <p>- - - - - - - - - - - - - Sign In With - - - - - - - - - - - - - </p>
    		<ul>
            <li><a href=""><i class="fa fa-facebook"></i> Facebook</a></li>
            <li><a href=""><i class="fa fa-google-plus"></i> Google+</a></li>
            <li><a href=""><i class="fa fa-twitter"></i> Twitter</a></li>
            </ul>
            </div> -->
            <div class="clearfix"></div>
        </div>
        <div id="sectionB" class="tab-pane fade">
			<div class="innter-form">
            <form class="sa-innate-form" method="post">
            <label>Full Name:</label>
            <input type="text" name="username">
            <label>Email Address:</label>
            <input type="text" name="username">
            <label>Password:</label>

            <input type="password" name="password">
             <label>Date of Birth:</label><br>
            <input type="date" name="dob" style=" width: 220px;"><br>
            <label>Contact No:</label>
            <span>
            	<br>
            <select style="width: 65px;" name="std">
            	
            	<option value="+44">+44</option>
            	<option>+44</option>
            	<option>+44</option>
            	<option>+44</option>
            	<option>+44</option>
            </select>
            <input type="text" name="mobile" style="width: 153px;"></span><br>
            <p><input type="checkbox"  required="required">Please tick box if you agree to the terms and conditions.</p>
            <button type="submit">Join now</button>
            
            </form>
            </div>
            <!-- <div class="social-login">
            <p>- - - - - - - - - - - - - Register With - - - - - - - - - - - - - </p>
			<ul>
            <li><a href=""><i class="fa fa-facebook"></i> Facebook</a></li>
            <li><a href=""><i class="fa fa-google-plus"></i> Google+</a></li>
            <li><a href=""><i class="fa fa-twitter"></i> Twitter</a></li>
            </ul>
            </div> -->
        </div>
    </div>
    </div>
				 </div>
			</div>
            </div>
			
			
	

	</div>
</div>
</div>
</div>
<div class="wpb_row pix-row vc_row-fluid vc_custom_1417500238804 dark normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-12 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<section class="eventform newsection">

			
			<div class="event-title">
				<small>Find what you want</small>
				<h2 class="title">event </h2>
			</div>

		<div class="eventform-con">
			<form method="get" action="#">

			<input name="post_type" type="hidden" value="pix_event">
				<div class="form-input search-location">
					<input name="keyword" type="text" value="" placeholder="Search Keyword">
					<i class="icon fa fa-search"></i>
				</div>

				<div class="form-input">
					<input name="date" placeholder="mm/dd/yy" class="date_timepicker_start">
					<i class="open icon fa fa-calendar"></i>
				</div>

				<div class="form-input">
					<div class="styled-select">
						<select name="loc" style="margin-top: 0px;"><option value="0">Select Venue</option><option value="Grand Hotel">Grand Hotel</option><option value="Blankenberge Belgian">Blankenberge Belgian</option><option value="Auckland Bay City">Auckland Bay City</option><option value="Liona Hotel">Liona Hotel</option><option value="Riboca Lodge">Riboca Lodge</option><option value="Barry's Point">Barry's Point</option></select>
						</div>
					</div>

					
					<button name="event_search" value="1" type="submit" class="btn btn-md btn-pri">fınd event</button>
					
				</form>
			</div>
	
	
</section>
		</div> 
	</div> 

	</div></div></div></div>
	<div class="wpb_row pix-row vc_row-fluid dark normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-12 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="tabs event-tab upcoming-popular-tab">
				<ul class="clearfix">
					<li>
						<a href="#tabs180215469">Popular Events</a>
						
					</li>
					<li>
						<a href="#tabs1062277384">Upcoming Events</a>
					</li>
				</ul>
				<div id="tabs1062277384">
	                <div class="event-container">
	                    <div class="row"><div>No Events Found.</div></div>
	                </div>
	            </div><div id="tabs180215469">
	                <div class="event-container">
	                    <div class="row"><div class="col-md-3">
                        		<div class="event bg">
                            		<div class='eventsimg'><img src='image/liveevent4.jpg' alt='' style="height: 200px;"></div>
                            		<div class="event-content">
                                	<h3 class="title">Globally Synthesize Growth Strategy</h3><p>Appropriately harness team driven data for... [...] </p><a href="#" class="btn btn-solid btn-blue btn-md">Buy Ticket</a></div><div class="links three clearfix">
					                    <ul>
					                    	<li><a class="st_sharethis_large" displayText="ShareThis"><i class="icon fa fa-share"></i> share</a></li>
					                    	<li><a href="#void" class="portfolio-icon pix-like-me " data-id="122"><i class="icon fa fa-heart"></i><span class="like-count">83</span></a></li>
					                    	<li><i class="icon fa fa-comment"></i>0</li> 
					                    </ul> 
					               	 </div></div></div><div class="col-md-3">
                        		<div class="event bg">
                            		<div class='eventsimg'><img src='image/LiveEvents1.jpg' alt='' style="height: 200px;"></div>
                            		<div class="event-content">
                                	<h3 class="title">Phosfluorescently Reinvent Intermandated Sources</h3><p>Authoritatively morph turnkey relationships... [...] </p><a href="#" class="btn btn-solid btn-blue btn-md">Buy Ticket</a></div><div class="links three clearfix">
					                    <ul>
					                    	<li><a class="st_sharethis_large" displayText="ShareThis"><i class="icon fa fa-share"></i> share</a></li>
					                    	<li><a href="#void" class="portfolio-icon pix-like-me " data-id="11"><i class="icon fa fa-heart"></i><span class="like-count">49</span></a></li>
					                    	<li><i class="icon fa fa-comment"></i>0</li> 
					                    </ul> 
					               	 </div></div></div><div class="col-md-3">
                        		<div class="event bg">
                            		<div class='eventsimg'><img src='image/liveevent3.jpg' alt='' style="height: 200px;"></div>
                            		<div class="event-content">
                                	<h3 class="title">Sysmatically Empower Inexpensive Infomation</h3><p>Professionally create one-to-one methodologies... [...] </p><a href="#" class="btn btn-solid btn-blue btn-md">Buy Ticket</a></div><div class="links three clearfix">
					                    <ul>
					                    	<li><a class="st_sharethis_large" displayText="ShareThis"><i class="icon fa fa-share"></i> share</a></li>
					                    	<li><a href="#void" class="portfolio-icon pix-like-me " data-id="9"><i class="icon fa fa-heart"></i><span class="like-count">37</span></a></li>
					                    	<li><i class="icon fa fa-comment"></i>0</li> 
					                    </ul> 
					               	 </div></div></div><div class="col-md-3">
                        		<div class="event bg">
                            		<div class='eventsimg'><img src='image/liveEvents2.png' alt='' style="height: 200px;"></div>
                            		<div class="event-content">
                                	<h3 class="title">Using Social Services Increase Your Sales</h3><p>Nunc sed turpis. Phasellus nec sem in justo... [...] </p><a href="#" class="btn btn-solid btn-blue btn-md">Buy Ticket</a></div><div class="links three clearfix">
					                    <ul>
					                    	<li><a class="st_sharethis_large" displayText="ShareThis"><i class="icon fa fa-share"></i> share</a></li>
					                    	<li><a href="#void" class="portfolio-icon pix-like-me " data-id="5"><i class="icon fa fa-heart"></i><span class="like-count">56</span></a></li>
					                    	<li><i class="icon fa fa-comment"></i>0</li> 
					                    </ul> 
					               	 </div></div></div></div>
	                </div>
	            </div><a href="#" target="_self" class="clear btn btn-border btn-md btn-color">View All Event</a></div>
		</div> 
	</div> 

	</div></div></div></div><div class="wpb_row pix-row vc_row-fluid vc_custom_1423313491995 light normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-12 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class=" callout border-cover  show_dual_btn"><h2 class="title"><span>so What are You Waiting For</span></h2> <div class="background-content clearfix"><p> Appropriately benchmark exceptional catalysts for change through viral applications. Collaboratively exploit enabled catalysts for. </p> <div class="both-btn clearfix">
	            <div class="find-events">
	                <a href="#">Find Events</a>
	            </div>

	            <div class="but-ticket">
	                <a href="#">Buy Tickets</a>
	            </div>

	            <span class="round">or</span>
	        </div></div></div>
		</div> 
	</div> 

	</div></div></div></div>

	<div class="wpb_row pix-row vc_row-fluid light normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-12 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			
		</div> 
	</div> 

	</div></div></div></div>


	<div class="wpb_row pix-row vc_row-fluid vc_custom_1423315608614 dark normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
		<div class="pix-container">
	<div class="vc_col-sm-3 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="event icon-box bg add_bg_hover"><div class="eventsicon square-border color md">
						<i class="fa fa-heart-o"></i>
					</div><div class="event-content">
						<h2 class="title">7/24 Everytime Event</h2><p>Professionally e-enable exceptional partnerships and cross-media data.[...] </p></div>
			</div>
		</div> 
	</div> 

	<div class="vc_col-sm-3 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="event icon-box bg add_bg_hover"><div class="eventsicon square-border color md">
						<i class="fa fa-calendar-o"></i>
					</div><div class="event-content">
						<h2 class="title">25+ Events Location</h2><p>Holisticly transition intuitive markets through dynamic leadership skills.[...] </p></div>
			</div>
		</div> 
	</div> 

	<div class="vc_col-sm-3 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="event icon-box bg add_bg_hover"><div class="eventsicon square-border color md">
						<i class="fa fa-umbrella"></i>
					</div><div class="event-content">
						<h2 class="title">50+ speakers</h2><p>Credibly expedite strategic products without granular interfaces.[...] </p></div>
			</div>
		</div> 
	</div> 

	<div class="vc_col-sm-3 wpb_column vc_column_container ">
		<div class="wpb_wrapper">
			<div class="event icon-box bg add_bg_hover"><div class="eventsicon square-border color md">
						<i class="fa fa-star-o"></i>
					</div><div class="event-content">
						<h2 class="title">Party After Events</h2><p>Synergistically iterate empowered testing procedures for systems.[...] </p></div>
			</div>
		</div> 
	</div> 

	</div></div></div></div>


			</section>

		</section>

				
		<footer class="footer col3" role="contentinfo">

							

					<div class="main-footer"><div id="inner-footer" class="container"><div id="text-2" class="widget widget_text clearfix "><h2 class="title">About Us<span class="border"></span></h2>			<div class="textwidget">Dynamically administrate equity invested networks via competitive human capital. Quickly orchestrate back end services whereas user manufactured products. Collaboratively fashion emerging metrics through real-time customer service. Progressively iterate dynamic interfaces after mission critical. Distinctively underwhelm plug-and-play meta-services and leading-edge paradigms.</div>
		</div>		
		<div id="pix_recent_post-3" class="widget recentpost clearfix ">		<h2 class="title">Recent Posts<span class="border"></span></h2>		
			<div class="sidebar-post-widget">
			<ul>
											<li class="clearfix">									
									<div class="content ">
										<p><a href="#">Professionally build market positioning materials</a></p>
										<span class="meta">March 9, 2015</span>
																			</div>
								</li>
	        
											<li class="clearfix">									
									<div class="content ">
										<p><a href="#">Globally benchmark strategic e-services</a></p>
										<span class="meta">March 9, 2015</span>
																			</div>
								</li>
	        
											<li class="clearfix">									
									<div class="content ">
										<p><a href="#">Rapidiously pontificate inexpensive customer service</a></p>
										<span class="meta">March 9, 2015</span>
																			</div>
								</li>
	        
						</ul>
		</div>
		</div>		
		<div id="pix_popular_post-3" class="widget popularpost clearfix ">		
			<h2 class="title">Address<span class="border"></span></h2>		
			<div class="sidebar-post-widget">
			<ul>
							<li class="clearfix">					
					<div class="content ">
						<p><a href="#">52 blanford street 
                                     <br>  London<br>
                                    Wx1h0bx</a><br>
                        <p>Contact No.:07737978513</p>
                                </p>
						<!-- <span class="meta">December 16, 2014</span> -->
											</div>
				</li>
	        
						
						</ul>
		</div>
		</div></div></div>
				

			<div id="copyright">
						<div class="container">
							<div class="copyright row"><div class="col-md-6"><p>© 2017 <a href="#">Comedyrunners</a> , All Rights Reserved.</p></div><div class="col-md-6"><div class="social-icon pull-right"><a href="#" class="facebook fa fa-facebook"></a><a href="#" class="twitter fa fa-twitter"></a><a href="#" class="googleplus fa fa-google-plus"></a><a href="#" class="linkedin fa fa-linkedin"></a><a href="#" class="flickr fa fa-flickr"></a><a href="#" class="pinterest fa fa-pinterest"></a><a href="#" class="tumblr fa fa-tumblr"></a><a href="#" class="rss fa fa-rss"></a></div></div></div>
						</div>
					</div>
		</footer>

		

				<script data-cfasync="false" src="../cdn-cgi/scripts/ddc5a536/cloudflare-static/email-decode.min.js"></script><script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/plugins/contact-form-7/includes/js/scripts.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif","i18n_view_cart":"View Cart","cart_url":"http:\/\/innwithemes.com\/eventonwp\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
var wc_add_to_cart_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif","i18n_view_cart":"View Cart","cart_url":"http:\/\/innwithemes.com\/eventonwp\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js'></script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif"};
var woocommerce_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif"};
/* ]]> */
</script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js'></script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","fragment_name":"wc_fragments"};
var wc_cart_fragments_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pixLike = {"ajaxurl":"http:\/\/innwithemes.com\/eventonwp\/wp-admin\/admin-ajax.php","liked":"You already liked this!"};
/* ]]> */
</script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/framework/required-functions/pix-like-me/js/like-me.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-includes/js/comment-reply.min.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/library/js/scripts.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/library/js/plugins.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/library/js/main.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/plugins/js_composer/assets/js/js_composer_front.js'></script>

	</body>

</html> <!-- end of site. what a ride! -->