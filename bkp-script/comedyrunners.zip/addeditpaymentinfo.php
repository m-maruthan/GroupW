<?php 
require_once 'conn.php';
if($_POST)
{
	//print_r($_POST);die;
	// $valid['success'] = array('success' => false, 'messages' => array());
  	$qry = mysqli_query($conn,"select * from `users_cards` where users_id='".$_POST['user_id']."'");
	if(mysqli_num_rows($qry)>0)
	{
   		$sql = mysqli_query($conn,"UPDATE `users_cards` SET `nameoncard` = '".$_POST['NameOnCard']."', `cardnumber`='".$_POST['CardNumber']."', `expirymonth`='".$_POST['cardmonth']."', `expiryyear`='".$_POST['cardyear']."', `cardcvv`='".$_POST['cvvno']."' WHERE users_id = '".$_POST['user_id']."'");
	} else {
		$sql = mysqli_query($conn,"insert into users_cards(nameoncard,cardnumber,expirymonth,expiryyear,cardcvv,users_id) values ('".$_POST['NameOnCard']."','".$_POST['CardNumber']."','".$_POST['cardmonth']."','".$_POST['cardyear']."','".$_POST['cvvno']."','".$_POST['user_id']."')");
	}

	if($sql===true)
	{
		  header("location:myaccount.php?ch=1");
 		$valid['messages'] = "Successfully Update";	
	}
	else {
		$valid['success'] = false;
		$valid['success'] = "Error while updating product info";
	}
	echo json_encode($valid);
}
?>