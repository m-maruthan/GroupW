<?php
   include('header.php');
?>





<div class="wpb_row pix-row vc_row-fluid light normal"><div class="bg-pos-rel"><div class="pix-con clearfix">
    <div class="pix-container">
  <div class="vc_col-sm-12 wpb_column vc_column_container ">
    <div class="wpb_wrapper">
          <div class="jumbotron">
            <h1>"Creating Memories Lasting A Lifetime..."</h1>
          </div>

          <div class="row">
            <div class="col-sm-12" style="background-color: white; padding: 30px;" >
                      <p style="font-size: 18px;">Comedyrunner is the world's largest comedy event technology platform. We build the technology to allow anyone to create, share, find and attend new things to bring humour  their lives.Our mission? To bring the world together through live experiences.</p>
                    </div>


                      <div class="container second-portion">
  <div class="row">
        <!-- Boxes de Acoes -->
      <div class="col-xs-12 col-sm-6 col-lg-4">
      <div class="box">             
        <div class="icon">
          <div class="image"><i class="fa fa-check" aria-hidden="true"></i></div>
          <div class="info">
           <!--  <h3 class="title">MAIL & WEBSITE</h3> -->
            <p>
             <!--  <i class="fa fa-envelope" aria-hidden="true"></i> &nbsp gondhiyahardik6610@gmail.com -->
              <br>
              <h3>Accredited by trading
standards.</h3>
              <br>
              <!-- <i class="fa fa-globe" aria-hidden="true"></i> &nbsp www.hardikgondhiya.com -->
            </p>
          
          </div>
        </div>
        <div class="space"></div>
      </div> 
    </div>
      
        <div class="col-xs-12 col-sm-6 col-lg-4">
      <div class="box">             
        <div class="icon">
          <div class="image"><i class="material-icons">looks_one <sup style="top: -1.5em!important;font-size: 40%!important; font-weight: bold;">ST</sup></i></div>
          <div class="info">
           <!--  <h3 class="title">CONTACT</h3> -->
              <p>
             <!--  <i class="fa fa-mobile" aria-hidden="true"></i> &nbsp (+91)-9624XXXXX -->
              <br>
              <h3>Number one event
platform globally</h3>
              <br>
              <!-- <i class="fa fa-mobile" aria-hidden="true"></i> &nbsp  (+91)-7567065254 --> 
            </p>
          </div>
        </div>
        <div class="space"></div>
      </div> 
    </div>
      
        <div class="col-xs-12 col-sm-6 col-lg-4">
      <div class="box">             
        <div class="icon">
          <div class="image"><i class="fa fa-ticket" aria-hidden="true"></i></div>
          <div class="info">
           <!--  <h3 class="title">ADDRESS</h3> -->
              <p>
               <!-- <i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp 15/3 Junction Plot 
               "Shree Krishna Krupa", Rajkot - 360001. -->
               <br>
               <h3>Millions of tickets sold/
processed each week.</h3>
            </p>
          </div>
        </div>
        <div class="space"></div>
      </div> 
    </div>        
    <!-- /Boxes de Acoes -->
    
    <!--My Portfolio  dont Copy this -->
      
  </div>
</div>
          </div>
    </div>  
  </div> 

  </div></div></div></div>
	

			
		<?php
          include('footer.php');
    ?>