<footer class="footer col3" role="contentinfo">

							

					<div class="main-footer"><div id="inner-footer" class="container"><div id="text-2" class="widget widget_text clearfix "><h2 class="title">About Us<span class="border"></span></h2>			<div class="textwidget">Dynamically administrate equity invested networks via competitive human capital. Quickly orchestrate back end services whereas user manufactured products. Collaboratively fashion emerging metrics through real-time customer service. Progressively iterate dynamic interfaces after mission critical. Distinctively underwhelm plug-and-play meta-services and leading-edge paradigms.</div>
		</div>		
		<div id="pix_recent_post-3" class="widget recentpost clearfix ">		<h2 class="title">Recent Posts<span class="border"></span></h2>		
			<div class="sidebar-post-widget">
			<ul>
											<li class="clearfix">									
									<div class="content ">
										<p><a href="#">Professionally build market positioning materials</a></p>
										<span class="meta">March 9, 2015</span>
																			</div>
								</li>
	        
											<li class="clearfix">									
									<div class="content ">
										<p><a href="#">Globally benchmark strategic e-services</a></p>
										<span class="meta">March 9, 2015</span>
																			</div>
								</li>
	        
											<li class="clearfix">									
									<div class="content ">
										<p><a href="#">Rapidiously pontificate inexpensive customer service</a></p>
										<span class="meta">March 9, 2015</span>
																			</div>
								</li>
	        
						</ul>
		</div>
		</div>		
		<div id="pix_popular_post-3" class="widget popularpost clearfix ">		
			<h2 class="title">Address<span class="border"></span></h2>		
			<div class="sidebar-post-widget">
			<ul>
							<li class="clearfix">					
					<div class="content ">
						<p><a href="#">52 blanford street 
                                     <br>  London<br>
                                    Wx1h0bx</a><br>
                        <p>Contact No.:07737978513</p>
                                </p>
						<!-- <span class="meta">December 16, 2014</span> -->
											</div>
				</li>
	        
						
						</ul>
		</div>
		</div></div></div>
				

			<div id="copyright">
						<div class="container">
							<div class="copyright row"><div class="col-md-6"><p>© 2017 <a href="#">Comedyrunners</a> , All Rights Reserved.</p></div><div class="col-md-6"><div class="social-icon pull-right"><a href="#" class="facebook fa fa-facebook"></a><a href="#" class="twitter fa fa-twitter"></a><a href="#" class="googleplus fa fa-google-plus"></a><a href="#" class="linkedin fa fa-linkedin"></a><a href="#" class="flickr fa fa-flickr"></a><a href="#" class="pinterest fa fa-pinterest"></a><a href="#" class="tumblr fa fa-tumblr"></a><a href="#" class="rss fa fa-rss"></a></div></div></div>
						</div>
					</div>
		</footer>

		

				<script data-cfasync="false" src="../cdn-cgi/scripts/ddc5a536/cloudflare-static/email-decode.min.js"></script><script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/plugins/contact-form-7/includes/js/scripts.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif","i18n_view_cart":"View Cart","cart_url":"http:\/\/innwithemes.com\/eventonwp\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
var wc_add_to_cart_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif","i18n_view_cart":"View Cart","cart_url":"http:\/\/innwithemes.com\/eventonwp\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js'></script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif"};
var woocommerce_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","ajax_loader_url":"\/\/innwithemes.com\/eventonwp\/wp-content\/plugins\/woocommerce\/assets\/images\/ajax-loader@2x.gif"};
/* ]]> */
</script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js'></script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","fragment_name":"wc_fragments"};
var wc_cart_fragments_params = {"ajax_url":"\/eventonwp\/wp-admin\/admin-ajax.php","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='//innwithemes.com/eventonwp/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pixLike = {"ajaxurl":"http:\/\/innwithemes.com\/eventonwp\/wp-admin\/admin-ajax.php","liked":"You already liked this!"};
/* ]]> */
</script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/framework/required-functions/pix-like-me/js/like-me.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-includes/js/comment-reply.min.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/library/js/scripts.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/library/js/plugins.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/themes/event/library/js/main.js'></script>
<script type='text/javascript' src='http://innwithemes.com/eventonwp/wp-content/plugins/js_composer/assets/js/js_composer_front.js'></script>

	</body>

</html> <!-- end of site. what a ride! -->